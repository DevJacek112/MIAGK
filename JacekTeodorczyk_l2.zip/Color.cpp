//
// Created by Jacek on 20.03.2025.
//

#include "Color.h"

Color::Color(int r, int g, int b, int a) : _r(r), _g(g), _b(b), _a(a) {

}