//
// Created by Jacek on 20.03.2025.
//

#ifndef COLOR_H
#define COLOR_H



class Color {

public:

    int _r = 0;
    int _g = 0;
    int _b = 0;
    int _a = 0;

    Color(int r, int g, int b, int a);

};



#endif //COLOR_H
